cares_togo_api/
├── app/
│   ├── main.py
│   ├── config.py
│   ├── models
│   │   ├── model_users.py
│   │   ├── model_homepage.py
│   ├── database.py
│   ├── routes/
│   │   ├── auth.py
│   │   ├── media.py
│   │   ├── blog.py
│   │   ├── partners.py
│   │   ├── homepage.py
│   ├── schemas.py
│   ├── services.py
├── .env
├── requirements.txt
├── alembic/
├── README.md
